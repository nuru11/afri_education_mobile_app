import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter/material.dart';

class ConfigPreference {
  // Prevent instantiation
  ConfigPreference._();

  static const String _preferencesBox = 'preferences';
  static const String _currentLocalKey = 'current_local';
  static const String _lightThemeKey = 'is_theme_light';
  static const String _isFirstLaunchKey = 'is_first_launch';
  static const String _accessTokenKey = 'access_token';
  static const String _askedStudyPlanNotificationKey =
      'asked_study_plan_notification_permission';
  static const String _askedStudyPlanExactAlarmKey =
      'asked_study_plan_exact_alarm_permission';
  static const String _pomodoroStateKey = 'pomodoro_state';
  static const String _parentModeKeyPrefix = 'parent_mode_enabled_';
  static const String _appAudienceKey = 'app_audience';
  static const String _parentLinkDeviceIdKey = 'parent_link_device_id';
  static const String _showParentModeKey = 'show_parent_mode';

  // Initialize Hive
  static Future<void> init() async {
    if (!Hive.isBoxOpen(_preferencesBox)) {
      await Hive.openBox<dynamic>(_preferencesBox);
    }
  }

  // Get Hive box
  static Box<dynamic> _getBox() {
    return Hive.box(_preferencesBox);
  }

  // Set theme to light/dark
  static Future<void> setThemeIsLight(bool lightTheme) async {
    await _getBox().put(_lightThemeKey, lightTheme);
  }

  // Get current theme (light or dark)
  static bool getThemeIsLight() {
    return _getBox().get(_lightThemeKey, defaultValue: true) as bool;
  }

  // Save current language
  static Future<void> setCurrentLanguage(String languageCode) async {
    await _getBox().put(_currentLocalKey, languageCode);
  }

  // Get current language
  static Locale getCurrentLocal() {
    String? langCode = _getBox().get(_currentLocalKey) as String?;
    return langCode == null ? const Locale('en') : Locale(langCode);
  }

  // Check if it's the first launch
  static bool isFirstLaunch() {
    return _getBox().get(_isFirstLaunchKey, defaultValue: true) as bool;
  }

  // Mark the app as launched
  static Future<void> markAppLaunched() async {
    await _getBox().put(_isFirstLaunchKey, false);
  }

  // Store access token
  static Future<void> storeAccessToken(String accessToken) async {
    await _getBox().put(_accessTokenKey, accessToken);
  }

  // Get access token
  static String? getAccessToken() {
    return _getBox().get(_accessTokenKey) as String?;
  }

  // Clear all stored data
  static Future<void> clear() async {
    await _getBox().clear();
  }

  /// Whether we already showed the in-app rationale for study plan notifications.
  static bool hasAskedStudyPlanNotificationPermission() {
    return _getBox().get(_askedStudyPlanNotificationKey, defaultValue: false)
        as bool;
  }

  static Future<void> setAskedStudyPlanNotificationPermission(
    bool value,
  ) async {
    await _getBox().put(_askedStudyPlanNotificationKey, value);
  }

  /// Whether we already showed the in-app rationale for exact alarm (Android).
  static bool hasAskedStudyPlanExactAlarmPermission() {
    return _getBox().get(_askedStudyPlanExactAlarmKey, defaultValue: false)
        as bool;
  }

  static Future<void> setAskedStudyPlanExactAlarmPermission(bool value) async {
    await _getBox().put(_askedStudyPlanExactAlarmKey, value);
  }

  static String? getPomodoroState() {
    return _getBox().get(_pomodoroStateKey) as String?;
  }

  static Future<void> setPomodoroState(String value) async {
    await _getBox().put(_pomodoroStateKey, value);
  }

  static bool isParentModeEnabled(int userId) {
    return _getBox().get('$_parentModeKeyPrefix$userId', defaultValue: false)
        as bool;
  }

  static Future<void> setParentModeEnabled(int userId, bool value) async {
    await _getBox().put('$_parentModeKeyPrefix$userId', value);
  }

  /// `student` or `parent` after the first-launch choice. Null until chosen.
  static AppAudience? getAppAudience() {
    final value = _getBox().get(_appAudienceKey) as String?;
    switch (value) {
      case 'student':
        return AppAudience.student;
      case 'parent':
        return AppAudience.parent;
      default:
        return null;
    }
  }

  static String? getParentLinkDeviceId() {
    final value = _getBox().get(_parentLinkDeviceIdKey) as String?;
    if (value == null || value.isEmpty) return null;
    return value;
  }

  static Future<void> setParentLinkDeviceId(String deviceId) async {
    await _getBox().put(_parentLinkDeviceIdKey, deviceId);
  }

  /// Null until the feature-flags request has succeeded at least once.
  static bool? getCachedShowParentMode() {
    final box = _getBox();
    if (!box.containsKey(_showParentModeKey)) return null;
    return box.get(_showParentModeKey) as bool?;
  }

  static Future<void> setCachedShowParentMode(bool value) async {
    await _getBox().put(_showParentModeKey, value);
  }

  static Future<void> setAppAudience(AppAudience audience) async {
    await _getBox().put(
      _appAudienceKey,
      audience == AppAudience.parent ? 'parent' : 'student',
    );
  }
}

enum AppAudience { student, parent }
